RAJA GAYATHRI — PORTFOLIO WEBSITE

Files:
- index.html: responsive portfolio website with your LinkedIn and GitHub profile links added.

Preview:
Open index.html in a browser.

Publish free with GitHub Pages:
1. Sign in to https://github.com/GAYATHRI-100
2. Create a PUBLIC repository named gayathri-portfolio.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. Wait for deployment. GitHub will show the public website address in Settings > Pages.
